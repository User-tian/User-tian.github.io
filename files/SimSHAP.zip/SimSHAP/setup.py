from setuptools import setup, find_packages
import os

# read requirements from "requirements.txt"
with open("requirements.txt", mode="r") as f:
    requirements_list = f.read().splitlines()

setup(
    name="simshap",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.9",
    install_requires=requirements_list
)