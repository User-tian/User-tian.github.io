import matplotlib.pyplot as plt


A = [1, 2, 3, 4, 5, 6, 7, 8, 9]
B = [1, 2, 3, 4, 5, 6, 7, 8, 9]

plt.plot(A, B)
plt.show()
plt.savefig('1.png')